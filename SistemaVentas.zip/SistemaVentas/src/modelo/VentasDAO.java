
package modelo;


public class VentasDAO {
    
}
